%%%%%<- written by Munir(0706043)->%%%%%

% train models using GMM following Isolated digit recognition
Fs = 8000;
modelidx = 33;
model = 11;
% model = strcat('t_pechone','.wav');
% [y1 Fs] = wavread(model);
y = filter([1 -0.97],1,y1);
figure,subplot(211),plot(y);
outline = zeros(1,length(y));
data = zeros(1,length(y));

windowSample = 256; %% 160 samples
intervalSample = 200; %% 160 samples
nfft = 512; % fft size
K = 20; % no of Mel filters
Q = 20; % no of Mel Cepstral Coefficient


nframes = (length(y) - intervalSample)/(windowSample - intervalSample);
nframes = floor(nframes);
MFCC = []; IMFCC = [];  Elog = []; 

noise = 5:30;
sig = y(noise);
Var = var(sig);
Mean = mean(sig);
alpha = 8*Mean^-0.9;
TOL =(Var + alpha*Mean);
Sc = 30000;
activityFrame = 30; % indicates at least howmany frames is speech
flag = 0;
startFrame = 0;
endFrame = 0;


for i = 1:nframes
    u = (i-1)*windowSample - (i-1)*intervalSample + 1;
    sig = y(u:u+windowSample-1);
    E = sum(sig.*sig);
    P = E/length(sig);
    Sign = sign(sig);
    temp = [Sign(2:end);0];
    change = Sign - temp;
    Z = (sum(abs(change)/2))/length(sig);
    W = P*(1 - Z)*Sc;
    
    if W > TOL
        flag = flag+1;
        outline(u:u+windowSample-1) = 1;
    else
        if flag > activityFrame
            start = startFrame*windowSample - startFrame*intervalSample + 1;
            endf = (i-2)*windowSample - (i-2)*intervalSample + windowSample;
            data(start:endf) = y1(start:endf);
            %<- notice i'm sending the actual data not the filtered one. ->%

            [mfccdata elog] = extractFeature( y1(start:endf),Fs,nfft,...
                                                 windowSample,intervalSample,K,Q);
 
            Elog = [Elog elog];
            nor = mean(mfccdata,2);
            [r c] = size(mfccdata);
            mfccdata = mfccdata - repmat(nor,1,c);
            d = (deltacoeff(mfccdata')).*0.6;     %Computes delta-mfcc
            d1 = (deltacoeff(d)).*0.4;        %as above for delta-delta-mfcc       
            MFCC = [MFCC [mfccdata;d';d1';]];
%             vq = vqlbg()
        end
        flag = 0;
        startFrame = i;
    end
end
% % %<- now post processing ->%
% % % no wondowing
% % % normalizing
% % nor = mean(MFCC,2);
% % [r c] = size(MFCC);
% % MFCC = MFCC - repmat(nor,1,c);
% % d = (deltacoeff(MFCC')).*0.6;     %Computes delta-mfcc
% % d1 = (deltacoeff(d)).*0.4;        %as above for delta-delta-mfcc
featureVector = [MFCC;]; 

hold on,plot(outline,'r');hold off
subplot(212),plot(data);
figure,imagesc((featureVector))

% 
% %%%% the training part

if exist('MODELSalpha.mat','file')
    load MODELSalpha
end

models(modelidx).word = model;

models(modelidx).VQ = kmeanlbg(featureVector',8);

figure,imagesc(models(modelidx).VQ)
save MODELSalpha models
% % options = statset('MaxIter',1000,'Display','final');
% % disp(['Starting GMM Training for: ' model]);
% % models(modelidx).gmm = gmdistribution.fit(featureVector',8,'CovType',...
% %     'diagonal','Options',options);
% % save MODELSalpha models




