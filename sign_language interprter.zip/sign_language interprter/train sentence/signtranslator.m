function varargout = signtranslator(varargin)
% SIGNTRANSLATOR MATLAB code for signtranslator.fig
%      SIGNTRANSLATOR, by itself, creates a new SIGNTRANSLATOR or raises the existing
%      singleton*.
%
%      H = SIGNTRANSLATOR returns the handle to a new SIGNTRANSLATOR or the handle to
%      the existing singleton*.
%
%      SIGNTRANSLATOR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SIGNTRANSLATOR.M with the given input arguments.
%
%      SIGNTRANSLATOR('Property','Value',...) creates a new SIGNTRANSLATOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before signtranslator_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to signtranslator_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help signtranslator

% Last Modified by GUIDE v2.5 29-May-2013 20:47:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @signtranslator_OpeningFcn, ...
                   'gui_OutputFcn',  @signtranslator_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before signtranslator is made visible.
function signtranslator_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to signtranslator (see VARARGIN)

% Choose default command line output for signtranslator
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes signtranslator wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = signtranslator_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h=waitbar(0,'Please wait..');
y1 = wavrecord(2*8000,8000);
close(h)
global word
detection
switch word
    case 1
       MyString='tomar nam ki?'; 
    case 2
        MyString=' tumi kemon acho ';
    case 3
        MyString='khelte jabe';
    case 4
       MyString='ami bhalo achhi'; 
    case 5
        MyString='cholo melay jai';
    case 6
        MyString='tv dekhbe';
    case 7
       MyString='tumi television dekho?'; 
    case 8
        MyString='kal porikkha kichu pori nai';
    case 9
        MyString='bujhi nai, abar bolo';
    case 10
       MyString='ami khub klanto'; 
    case 11
        MyString='berate jabe?';
    otherwise
       
end
set(handles.text,'String',MyString)



% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1
imshow('sound.jpg')


% --- Executes during object creation, after setting all properties.
function text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
