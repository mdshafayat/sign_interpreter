%%%%%<- written by Munir(0706043)->%%%%%
Fs = 8000;
% [y1 Fs]= wavread('hat_tolo.wav');
y = filter([1 -0.97],1,y1);
figure,subplot(211),plot(y);
outline = zeros(1,length(y));
data = zeros(1,length(y));
windowSample = 256;
intervalSample = 200;
nframes = (length(y) - intervalSample)/(windowSample - intervalSample);

noise = 5:30;
sig = y(noise);
Var = var(sig);
Mean = mean(sig);
alpha = 50*Mean^-1;
TOL =(Var + alpha*Mean);
Sc = 30000;
activityFrame = 20;
falg = 0;
startFrame = 0;
endFrame = 0;

for i = 1:nframes
    u = (i-1)*windowSample - (i-1)*intervalSample + 1;
    sig = y(u:u+windowSample-1);
    E = sum(sig.*sig);
    P = E/length(sig);
    Sign = sign(sig);
    temp = [Sign(2:end);0];
    change = Sign - temp;
    Z = (sum(abs(change)/2))/length(sig);
    W = P*(1 - Z)*Sc;
    
    if W > TOL
        flag = flag+1;
        outline(u:u+windowSample-1) = 1;
    else
        outline(u:u+windowSample-1) = 0;
        if flag > activityFrame
            start = startFrame*windowSample - startFrame*intervalSample + 1;
            endf = (i-2)*windowSample - (i-2)*intervalSample + windowSample;
            data(start:endf) = y1(start:endf);
        end
        flag = 0;
        startFrame = i;
    end
end
hold on,plot(outline,'r');hold off
subplot(212),plot(data);