function execHGR()

imaqreset

initDB();

letter=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',...
    'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u','v','w','x','y','z' ];
NET.addAssembly('System.Speech');
Speaker = System.Speech.Synthesis.SpeechSynthesizer;

vid = videoinput('winvideo', 2, 'YUY2_320x240')

% Set the properties of the video object
set(vid, 'FramesPerTrigger', Inf);
set(vid, 'ReturnedColorspace', 'rgb')
vid.FrameGrabInterval = 3;

while(1)
    preview(vid)

    Speaker.Speak ('show the gesture');

    %wait
    inp=input('ready? to quit press 0:');

    if inp==0
        break;
    end

    start(vid)
    data1 = getsnapshot(vid);
    data1=imresize(data1,0.625);

    imwrite(data1,'Images/Inputs/sample/A.jpg', 'jpg')
    flushdata(vid)

    stop(vid)
    stoppreview(vid)

    im='Images/Inputs/sample/A.jpg';
    figure
    [a results]=hgr(im);

    if a==0
        Speaker.Speak ('space');
        import java.awt.Robot;
        import java.awt.event.*;
        
        keyboard=Robot;
        keyboard.keyPress(KeyEvent.VK_SPACE)
        keyboard.keyRelease(KeyEvent.VK_SPACE)
        
    else
        Speaker.Speak (letter(a));
        inputemu('key_normal',letter(a));
    end
     
end
 
 
