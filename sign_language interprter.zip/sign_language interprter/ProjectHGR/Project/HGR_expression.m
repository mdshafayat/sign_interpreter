function HGR_expression()

imaqreset

initDB();
text1='Be careful';
text2='lets rock';
text3='go away';
text4='call';
text5='long live and prosper';
text6='Best of luck';
text7='shame on you';
text8='ok';
text9='cross';
text10='lets shake hands';
text11='victory';

NET.addAssembly('System.Speech');
Speaker = System.Speech.Synthesis.SpeechSynthesizer;

vid = videoinput('winvideo', 2,'YUY2_320x240');

% Set the properties of the video object
set(vid, 'FramesPerTrigger', Inf);
set(vid, 'ReturnedColorspace', 'rgb')
vid.FrameGrabInterval = 3;

while(1)
    preview(vid)

    Speaker.Speak ('show the gesture');

    %wait
    inp=input('ready? to quit press 0:');

    if inp==0
        break;
    end

    start(vid)
    data1 = getsnapshot(vid);
    data1=imresize(data1,0.625);

    imwrite(data1,'Images/Inputs/sample/A.jpg', 'jpg')
    flushdata(vid)

    stop(vid)
    stoppreview(vid)

    im='Images/Inputs/sample/A.jpg';

    [a results]=hgr(im);

    if a==0
        Speaker.Speak ('space');
        import java.awt.Robot;
        import java.awt.event.*;
        
        keyboard=Robot;
        keyboard.keyPress(KeyEvent.VK_SPACE)
        keyboard.keyRelease(KeyEvent.VK_SPACE)
        
    else
        if a==1
            Speaker.Speak (text1);
            inputemu('key_normal',text1);
        elseif a==2
            Speaker.Speak (text2);
            inputemu('key_normal',text2);
        elseif a==3
            Speaker.Speak (text3);
            inputemu('key_normal',text3);
        elseif a==4
            Speaker.Speak (text4);
            inputemu('key_normal',text4);
        elseif a==5
            Speaker.Speak (text5);
            inputemu('key_normal',text5);
        elseif a==6
            Speaker.Speak (text6);
            inputemu('key_normal',text6);
        elseif a==7
            Speaker.Speak (text7);
            inputemu('key_normal',text7);
        elseif a==8
            Speaker.Speak (text8);
            inputemu('key_normal',text8);
        elseif a==9
            Speaker.Speak (text9);
            inputemu('key_normal',text9);
        elseif a==10
            Speaker.Speak (text10);
            inputemu('key_normal',text10);
        elseif a==11
            Speaker.Speak (text11);
            inputemu('key_normal',text11);
        end
    end
     
end
 
 
