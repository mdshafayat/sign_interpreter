%0)initialize the dataset %after the prototype make it .mat file for
%speeding up the process
function initDB()

global Selecteds
Selecteds= zeros(1,26);
files = dir('Images/Database/*.jpg');
jj=size(files,1);
for l=1:jj
    nm=str2num(strrep(files(l).name,'.jpg',''));
    Selecteds(nm)=nm;
end
for i=1:26
    if(i<10)
        dataBase(i,:)=['Images/Database/' int2str(i) '.jpg ']; 
        
    end    
    if(i>9)
        dataBase(i,:)=['Images/Database/' int2str(i) '.jpg'];
        
    end    
end

save theHGRDatabase