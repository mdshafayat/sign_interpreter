
function [MFCC MFSC]= mfcc(y,Fs,nfft,K,Q)

%%%%%<- written by Munir(0706043)->%%%%%

% Calculates Mel Frequency Cepstral Coefficient
% Referrence : 
% An Introduction to Speech Recognition
%                B. Plannerer
%               March 28, 2005
% modified to include liftering and alpha factor

DCTmatrix = zeros(K,K); 

%pre emphasis filtering
emphasized = filter([1 -0.97],1,y);
%windowing by Hamming window
HamWindow = hamming(length(y));
WinEmp = HamWindow.*emphasized;

MFSC = mfsc(WinEmp,Fs,nfft,K);
%<- multiplying by alpha ->%
alpha = zeros(length(MFSC),1);
alpha(:,1) = sqrt(2/K); alpha(1,1) = sqrt(1/K);
G = log10(MFSC);
G = alpha.*G;
for q = 0:K-1   
    k = 0:K-1;
    DCTmatrix(q+1,k+1) = cos(pi*q*(2*k+1)/(2*K));
end

MFCC = DCTmatrix*G;
MFCC = MFCC(1:Q);

%<- now perform liftering ->%
L = Q;%round(2*K/3);
l = 0:L-1;
lift(:,1) = 1 + ((L-1)/2)*sin(pi*l/(L-1));
MFCC = MFCC(l+1).*lift;
% MFCC = MFCC(1:Q);



