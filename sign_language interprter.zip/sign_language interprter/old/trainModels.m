%%%%%<- written by Munir(0706043)->%%%%%

% train models using GMM following Isolated digit recognition
sounds = char('achhi_1','achhi_2','achhi_3','achhi_4','achhi_5','achho_1','achho_2','achho_3','achho_4','achho_5',...
    'ami_1','ami_2','ami_3','ami_4','ami_5','amader_1','amader_2','amader_3','amader_4','amader_5',...
    'amra_1','amra_2','amra_3','amra_4','amra_5','tumi_1','tumi_2','tumi_3','tumi_4','tumi_5',...
    'tomar_1','tomar_2','tomar_3','tomar_4','tomar_5','amar_1','amar_2','amar_3','amar_4','amar_5',...
    'asho_1','asho_2','asho_3','asho_4','asho_5','bari_1','bari_2','bari_3','bari_4','bari_5',...
    'bhalo_1','bhalo_2','bhalo_3','bhalo_4','bhalo_5','cholo_1','cholo_2','cholo_3','cholo_4','cholo_5',...
    'jabe_1','jabe_2','jabe_3','jabe_4','jabe_5','jai_1','jai_2','jai_3','jai_4','jai_5',...
    'kemon_1','kemon_2','kemon_3','kemon_4','kemon_5','kheli_1','kheli_2','kheli_3','kheli_4','kheli_5',...
    'myalay_1','myalay_2','myalay_3','myalay_4','myalay_5','shathe_1','shathe_2','shathe_3','shathe_4','shathe_5');
for z = 1:size(sounds,1)
modelidx = z;
model = strcat(sounds(z,:),'.wav');
[y1 Fs] = wavread(model);
y = filter([1 -0.97],1,y1);
figure,subplot(211),plot(y);
outline = zeros(1,length(y));
data = zeros(1,length(y));

windowSample = 20e-3*Fs; %% 300 samples
intervalSample = 20e-3*Fs/2; %% 160 samples
nfft = 512; % fft size
K = 20; % no of Mel filters
Q = 20; % no of Mel Cepstral Coefficient


nframes = (length(y) - intervalSample)/(windowSample - intervalSample);
nframes = floor(nframes);
MFCC = []; IMFCC = [];  Elog = []; 

noise = 1:50;
sig = y(noise);
Var = var(sig);
Mean = mean(sig);
alpha = 10*Mean^-1;
TOL =(Var + alpha*Mean);
Sc = 20000;
activityFrame = 5; % indicates at least howmany frames is speech
flag = 0;
startFrame = 0;
endFrame = 0;


for i = 1:nframes
    u = (i-1)*windowSample - (i-1)*intervalSample + 1;
    sig = y(u:u+windowSample-1);
    E = sum(sig.*sig);
    P = E/length(sig);
    Sign = sign(sig);
    temp = [Sign(2:end);0];
    change = Sign - temp;
    Z = (sum(abs(change)/2))/length(sig);
    W = P*(1 - Z)*Sc;
    
    if W > TOL
        flag = flag+1;
        outline(u:u+windowSample-1) = 1;
    else
        if flag > activityFrame
            start = startFrame*windowSample - startFrame*intervalSample + 1;
            endf = (i-2)*windowSample - (i-2)*intervalSample + windowSample;
            data(start:endf) = y1(start:endf);
            %<- notice i'm sending the actual data not the filtered one. ->%

            [mfccdata mfscdata elog] = extractFeature( y1(start:endf),Fs,nfft,...
                                                 windowSample,intervalSample,K,Q); 

            Elog = [Elog elog];
            nor = mean(mfccdata,2);
            [r c] = size(mfccdata);
            mfccdata = mfccdata - repmat(nor,1,c);
            d = (deltacoeff(mfccdata')).*0.6;     %Computes delta-mfcc
            d1 = (deltacoeff(d)).*0.4;        %as above for delta-delta-mfcc       
            MFCC = [MFCC [mfccdata;d';d1';]];
        end
        flag = 0;
        startFrame = i;
    end
end
% % %<- now post processing ->%
% % % no wondowing
% % % normalizing
% % nor = mean(MFCC,2);
% % [r c] = size(MFCC);
% % MFCC = MFCC - repmat(nor,1,c);
% % d = (deltacoeff(MFCC')).*0.6;     %Computes delta-mfcc
% % d1 = (deltacoeff(d)).*0.4;        %as above for delta-delta-mfcc
featureVector = [Elog;MFCC]; 

hold on,plot(outline,'r');hold off
subplot(212),plot(data);
% figure,imagesc((featureVector))

% 
% %%%% the training part

if exist('MODELSalpha.mat','file')
    load MODELSalpha
end

% modelidx = ;
models(modelidx).word = model;

models(modelidx).VQ = kmeanlbg(featureVector',8);

figure,imagesc(models(modelidx).VQ)
save MODELSalpha models
end



