
%%%%%<- written by Munir(0706043)->%%%%%
numOfWords = 90;
% 'dane','baye','jao',...
%     'samne','pechone','180','360','dourao','sundor','gan','gao','ghuro','
%     dhoro','nam','hello','bolo'

% [y1 Fs] = wavread('t_pechone.wav');
% y1 = y1(1:10000);
Fs = 8000;
y = filter([1 -0.97],1,y1);

outline = zeros(1,length(y));
data = zeros(1,length(y));

windowSample = 20e-3*Fs; %% 160 samples
intervalSample = 20e-3*Fs/2; %% 160 samples
nfft = 512; % fft size
K = 20; % no of Mel filters
Q = 20; % no of Mel Cepstral Coefficient

nframes = (length(y) - intervalSample)/(windowSample - intervalSample);
nframes = floor(nframes);


noise = 1:50;
sig = y(noise);
Var = var(sig);
Mean = mean(sig);
alpha = 10*Mean^-1;
TOL =(Var + alpha*Mean);
Sc = 20000;
activityFrame = 5; % indicates at least howmany frames is speech
flag = 0;
startFrame = 0;
endFrame = 0;


for i = 1:nframes
    u = (i-1)*windowSample - (i-1)*intervalSample + 1;
    sig = y(u:u+windowSample-1);
    E = sum(sig.*sig);
    P = E/length(sig);
    Sign = sign(sig);
    temp = [Sign(2:end);0];
    change = Sign - temp;
    Z = (sum(abs(change)/2))/length(sig);
    W = P*(1 - Z)*Sc;
    
    if W > TOL
        flag = flag+1;
        outline(u:u+windowSample-1) = 1;
    else
        if flag > activityFrame
            MFCC = []; IMFCC = [];  Elog = []; 
            start = startFrame*windowSample - startFrame*intervalSample + 1;
            endf = (i-2)*windowSample - (i-2)*intervalSample + windowSample;
            data(start:endf) = y1(start:endf);
            %<- notice i'm sending the actual data not the filtered one. ->%

            [mfccdata mfscdata elog] = extractFeature(y1(start:endf),Fs,nfft,...
                                                 windowSample,intervalSample,K,Q);     

            Elog = [Elog elog];
            nor = mean(mfccdata,2);
            [r c] = size(mfccdata);
            mfccdata = mfccdata - repmat(nor,1,c);
            d = (deltacoeff(mfccdata')).*0.6;     %Computes delta-mfcc
            d1 = (deltacoeff(d)).*0.4;        %as above for delta-delta-mfcc
            MFCC = [MFCC [mfccdata;d';d1';]];
            featureVector = [Elog;MFCC;]; 
            word = matchModel(featureVector,numOfWords)
        end
        flag = 0;
        startFrame = i;
    end
end
%<- now post processing ->%
% no wondowing
% % % normalizing
% % nor = mean(MFCC,2);
% % [r c] = size(MFCC);
% % MFCC = MFCC - repmat(nor,1,c);
% % d = (deltacoeff(MFCC')).*0.6;     %Computes delta-mfcc
% % d1 = (deltacoeff(d)).*0.4;        %as above for delta-delta-mfcc

figure,subplot(211),plot(y);
hold on,plot(outline,'r');hold off
subplot(212),plot(data);
% figure,imagesc(featureVector)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% now matching part

