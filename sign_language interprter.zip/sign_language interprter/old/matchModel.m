function mostLikely = matchModel(featureVector,numOfWords)
load MODELSalpha.mat

distmin = Inf;
k1 = 0;
for ii=1:numOfWords
     d = disteusq(featureVector', models(ii).VQ,'s');
     dist = sum(min(d,[],2)) / size(d,1);
     if dist < distmin
        distmin = dist;
        k1 = ii;
     end
end
min_index = k1;

mostLikely = models(min_index).word;