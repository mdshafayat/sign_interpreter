
function W = makeW(Fs,K,nfft)

%%%%%<- written by Munir(0706043)->%%%%%

% Fs = sampling frequency
% K = number of filters
% Referrence : 
% An Introduction to Speech Recognition
%                B. Plannerer
%               March 28, 2005

fmaxReg = Fs/2-133.33; 
fmaxMel = reg2mel(fmaxReg);
fminReg = 133.3;
fminMel = reg2mel(fminReg);
MelStep = (fmaxMel-fminMel)/(K+1);
DelF = Fs/nfft;
fcenterMel = (1:K)*MelStep+fminMel;
flowerMel = (0:K-1)*MelStep+fminMel;
fupperMel = (2:K+1)*MelStep+fminMel;
fcenterReg = mel2reg(fcenterMel);
flowerReg = mel2reg(flowerMel);
fupperReg = mel2reg(fupperMel);
nCenter = round(fcenterReg/DelF)+1;
nLower = round(flowerReg/DelF)+1;
nUpper = round(fupperReg/DelF)+1; 
nUpper(end) = nUpper(end)-1;
WHeight = 2./(fupperReg-flowerReg); % from Malcom Slaney's func

W = zeros(K,nfft/2+1);
for i = 1:K  %<- using triangular window ->%
    W(i,nLower(i):nCenter(i)) = linspace(0,1,length(nLower(i):nCenter(i)))*WHeight(i);
    W(i,nCenter(i):nUpper(i)) = linspace(1,0,length(nCenter(i):nUpper(i)))*WHeight(i);
end

% % for i = 1:K %<- using gaussian window ->%
% %     sig = (nUpper(i) - nCenter(i))/4;
% %     W(i,nLower(i):nUpper(i)) = gaussmf(nLower(i):nUpper(i),[sig nCenter(i)]);%*WHeight(i);
% % end

% % for i = 1:K
% %     plot(W(i,:));
% %     hold on;
% % end
% % 

function freg = mel2reg(fmel)
% Mel frequency to Regular frequency
freg = 700*(10.^(fmel/2595) - 1);

function fmel = reg2mel(freg)
% Regular frequency to Mel frequency
fmel = 2595*log10(1+(freg/700));