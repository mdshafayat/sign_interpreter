%%%%%<- written by Munir(0706043)->%%%%%

% train models using GMM following Isolated digit recognition
% sounds = char('180','360','dourao','dane','baye','gan','gao','hi5','jao','sundor',...
%     'samne','pechone','ghuro','dhoro','rakho','kemon_acho','namki');

modelidx = 20;
model = strcat('nachteparo','.wav');
[y1 Fs] = wavread(model);
y = filter([1 -0.97],1,y1);
figure,subplot(211),plot(y);
outline = zeros(1,length(y));
data = zeros(1,length(y));

windowSample = 20e-3*Fs; %% 300 samples
intervalSample = 20e-3*Fs/2; %% 160 samples
nfft = 512; % fft size
K = 20; % no of Mel filters
Q = 20; % no of Mel Cepstral Coefficient


nframes = (length(y) - intervalSample)/(windowSample - intervalSample);
nframes = floor(nframes);
MFCC = []; IMFCC = [];  Elog = []; 

noise = 1:50;
sig = y(noise);
Var = var(sig);
Mean = mean(sig);
alpha = 0.2*Mean^-0.8;
TOL =(Var + alpha*Mean);
Sc = 20000;
activityFrame = 5; % indicates at least howmany frames is speech
flag = 0;
startFrame = 0;
endFrame = 0;


for i = 1:nframes
    u = (i-1)*windowSample - (i-1)*intervalSample + 1;
    sig = y(u:u+windowSample-1);
    E = sum(sig.*sig);
    P = E/length(sig);
    Sign = sign(sig);
    temp = [Sign(2:end);0];
    change = Sign - temp;
    Z = (sum(abs(change)/2))/length(sig);
    W = P*(1 - Z)*Sc;
    
    if W > TOL
        flag = flag+1;
        outline(u:u+windowSample-1) = 1;
    else
        if flag > activityFrame
            start = startFrame*windowSample - startFrame*intervalSample + 1;
            endf = (i-2)*windowSample - (i-2)*intervalSample + windowSample;
            data(start:endf) = y1(start:endf);
            %<- notice i'm sending the actual data not the filtered one. ->%

            [mfccdata mfscdata elog] = extractFeature( y1(start:endf),Fs,nfft,...
                                                 windowSample,intervalSample,K,Q); 

            Elog = [Elog elog];
            nor = mean(mfccdata,2);
            [r c] = size(mfccdata);
            mfccdata = mfccdata - repmat(nor,1,c);
            d = (deltacoeff(mfccdata')).*0.6;     %Computes delta-mfcc
            d1 = (deltacoeff(d)).*0.4;        %as above for delta-delta-mfcc       
            MFCC = [MFCC [mfccdata;d';d1';]];
        end
        flag = 0;
        startFrame = i;
    end
end
% % %<- now post processing ->%
% % % no wondowing
% % % normalizing
% % nor = mean(MFCC,2);
% % [r c] = size(MFCC);
% % MFCC = MFCC - repmat(nor,1,c);
% % d = (deltacoeff(MFCC')).*0.6;     %Computes delta-mfcc
% % d1 = (deltacoeff(d)).*0.4;        %as above for delta-delta-mfcc
featureVector = [Elog;MFCC]; 
featureVector = repmat(featureVector,1,1);
hold on,plot(outline,'r');hold off
subplot(212),plot(data);
figure,imagesc((featureVector))

% 
% %%%% the training part

if exist('MODELSalpha.mat','file')
    load MODELSalpha
end

% modelidx = ;
models(modelidx).word = model;

models(modelidx).VQ = kmeanlbg(featureVector',8);
figure,imagesc(models(modelidx).VQ)
save MODELSalpha models




